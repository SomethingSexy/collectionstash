<?php
class FileUploadAppController extends AppController {
  
}
?>